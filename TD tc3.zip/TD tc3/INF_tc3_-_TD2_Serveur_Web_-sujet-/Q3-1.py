# -*- coding: utf-8 -*-
"""
Created on Tue May  9 16:27:51 2017

@author: matthieuweber
"""

import http.server
import socketserver

# définition du nouveau handler


class RequestHandler(http.server.SimpleHTTPRequestHandler):
    
    # sous-répertoire racine des documents statiques
    static_dir = '/client'
    
    # on surcharge la méthode qui traite les requêtes GET
    
    def do_GET(self):
        
        # on modifie le chemin d'accès en insérant un répertoire préfixe
        self.path = self.static_dir + self.path
        
        http.server.SimpleHTTPRequestHandler.do_GET(self)
        
        
# instanciation et lancement du serveur
        
httpd = socketserver.TCPServer(("", 8080), RequestHandler)
httpd.serve_forever()