# -*- coding: utf-8 -*-
"""
Created on Tue May  9 16:27:58 2017

@author: matthieuweber
"""

import http.server
import socketserver

httpd = socketserver.TCPServer(
        # adresse IP par défaut 127.0.0.1 et port 8080
        ("", 8080),
        # gestionnaire de requêtes pour servir des ressources statiques
        http.server.SimpleHTTPRequestHandler
        )


httpd.serve_forever()

do_GET()